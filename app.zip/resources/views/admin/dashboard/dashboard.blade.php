@extends('admin.layout.index')

@section('content')

<div id="content">
	<div id="content-header">
    <div id="breadcrumb"> <a title="" class="tip-bottom"><i class="icon-home"></i> Loại tin</a></div>
  </div>

<?php   ?>
	
</div>

 @endsection