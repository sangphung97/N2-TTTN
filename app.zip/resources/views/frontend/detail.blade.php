@extends('frontend.layout.parent')

@section('title','Chi Tiết Tin')
