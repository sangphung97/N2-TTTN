
<?php $__env->startSection('content'); ?>
<div class="container-fluid" style="padding:30px 5%">
    
    
    <div class="row">

    
    
        
        <div class="col-md-2">
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Neque quos minus, repellendus molestias quibusdam itaque ullam obcaecati facere est similique ad assumenda deserunt dolores. Illo, ut itaque. Nostrum, nesciunt beatae?
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Neque quos minus, repellendus molestias quibusdam itaque ullam obcaecati facere est similique ad assumenda deserunt dolores. Illo, ut itaque. Nostrum, nesciunt beatae?
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Neque quos minus, repellendus molestias quibusdam itaque ullam obcaecati facere est similique ad assumenda deserunt dolores. Illo, ut itaque. Nostrum, nesciunt beatae?
        </div>
        
        
        <div class="col-md-7" >
              <div class="col-md-8"> 
                        <?php $__currentLoopData = $nhomtin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>        
                        <?php if($nt->trangthai==1): ?>           
                        <h2 style="border-bottom: 1px solid black;width: 80%"><?php echo e($nt->ten_nhomtin); ?></h2>
                        <?php endif; ?>
                        <?php $__currentLoopData = $inhomtin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $int): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <?php if($int->id_nhomtin == $nt->id_nhomtin): ?>
                            <div class="row">
                                <div class="col-md-6" style="margin:15px 0">
                                    
                                        <a href="#">
                                            <img src="<?php echo e(asset('upload/tintuc/'.$int->hinhdaidien)); ?>" alt="img" style="width: 100%" >
                                        </a>
                                </div>
                                <div class="col-md-6" style="margin:15px 0">        
                                        <h4>
                                            <a href="#"><?php echo e($int->tieude); ?></a>
                                        </h4>
                                        <p>
                                            <a href="#"><?php echo e($int->mota); ?></a>
                                        </p>     
                                </div>
                            </div>
                       
                        
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
            
                 </div>
                
            
        </div>
        
        
        <div class="col-md-3" style="padding:0">
            <div class="row">
                <h2 style="border-bottom:1px solid">
                    Tác Giả
                </h2>
                <?php $__currentLoopData = $tin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12">
                    <a href="#" class="tg">
                        <?php echo e($tt->tacgia); ?>

                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <h2 style="border-bottom:1px solid">
                    Tin Hot
                </h2>
                <?php $__currentLoopData = $tin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($tt->tinhot==1): ?>
                <div class="col-md-12" style="padding:0">
                    <div class="row">
                            <div class="col-md-6"style="padding:0;margin-bottom:20px">
                            <a href="#">
                                <img src="<?php echo e(asset('upload/tintuc/'.$tt->hinhdaidien)); ?>" alt="tinhot" style="width:100%">
                            </a>
                        </div>
                        <div class="col-md-6">
                            <a href="#">
                                
                                <?php echo e($tt->mota); ?>

                            </a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        
   </div> 
</div>  

</div>  

<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\tttn\resources\views/frontend/layout/list.blade.php ENDPATH**/ ?>