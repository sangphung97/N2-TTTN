<?php $__env->startSection('title','Home'); ?>


<?php if ($__env->exists('frontend.layout.navigation')) echo $__env->make('frontend.layout.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if ($__env->exists('frontend.layout.header-body')) echo $__env->make('frontend.layout.header-body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if ($__env->exists('frontend.layout.list')) echo $__env->make('frontend.layout.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('frontend.layout.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tttn\resources\views/frontend/index.blade.php ENDPATH**/ ?>