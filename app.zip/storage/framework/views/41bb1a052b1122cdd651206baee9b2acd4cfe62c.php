<?php $__currentLoopData = $list_nhomtin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($item->tennhomtin); ?> 
    <br>
    <?php echo e($item->ten_loaitin); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\tttn\resources\views/frontend/demo.blade.php ENDPATH**/ ?>