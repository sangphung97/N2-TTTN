<?php $__env->startSection('content'); ?>


<div id="content">

<div id="content-header">
    <div id="breadcrumb"> <a title="" class="tip-bottom"><i class="icon-home"></i> Nhóm tin</a></div>
  </div>
<div class="container-fluid" >
  <hr>
  <div class="row-fluid">
    <div class="span6">

       <?php if(count($errors)>0): ?>
            <div class="alert"> 
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($err); ?><br>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          <?php endif; ?>



          <?php if(session('thongbao')): ?>
          <div class="alert">
            
            <?php echo e(session('thongbao')); ?>

          </div>
          <?php endif; ?>


      <div class="widget-box" >
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i></span>
          <h5>Thêm nhóm tin</h5>
        </div>
        <div class="widget-content nopadding">




          <form action="admin/nhomtin/them.html" method="POST" class="form-horizontal">

              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>

            
            <div class="control-group">
              <label class="control-label">Tên nhóm tin:</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="" name="ten" />
              </div>
            </div>
                   
            <div class="form-actions">
              <button type="submit" class="btn btn-success">Xác nhận</button>
              
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tttn\resources\views/admin/nhomtin/them.blade.php ENDPATH**/ ?>