<?php $__env->startSection('nav'); ?>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark" style="position:sticky;top:0;z-index:1000">
    <!-- Brand -->
    
  
    <!-- Links -->
    
    <ul class="navbar-nav">     
  
      <!-- Dropdown -->
      <?php $__currentLoopData = $loaitin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($lt->trangthai==1): ?>
      <li class="nav-item dropdown">
        
        <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown" style="color:white!important">
          <?php echo e($lt->ten_loaitin); ?>

        </a>
         <?php $__currentLoopData = $lt->tin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="#" ><?php echo e($tt->tieude); ?></a>
          
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </li>
      <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <form class="form-inline" action="/action_page.php">
        <input class="form-control mr-sm-2" type="text" placeholder="Search">
        <button class="btn btn-success" type="submit">Search</button>
    </form>
  </nav>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\tttn\resources\views/frontend/layout/navigation.blade.php ENDPATH**/ ?>