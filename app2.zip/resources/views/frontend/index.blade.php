@extends('frontend.layout.parent')
@section('title','Home')


@includeIf('frontend.layout.navigation')
@includeIf('frontend.layout.header-body')
@includeIf('frontend.layout.list')
