<?php $__env->startSection('content'); ?>

<div id="content">
	<div id="content-header">
    <div id="breadcrumb"> <a title="" class="tip-bottom"><i class="icon-home"></i> Loại tin</a></div>
  </div>

<?php   ?>
	
</div>

 <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tttn\resources\views/admin/dashboard/dashboard.blade.php ENDPATH**/ ?>