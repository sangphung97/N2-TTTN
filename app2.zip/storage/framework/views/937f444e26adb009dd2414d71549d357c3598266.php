

<div id="sidebar">
  <ul>
    <li class=""><a href="admin/dashboard.html"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
    
    


<li class="submenu"> <a href="#"><i class="icon icon-th-list"></i> <span>Nhóm tin</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="admin/nhomtin/danhsach.html">Danh sách</a></li>
        <li><a href="admin/nhomtin/them.html">Thêm</a></li>

      </ul>
    </li>


    <li class="submenu"> <a href="#"><i class="icon icon-th-list"></i> <span>Loại tin</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="admin/loaitin/danhsach.html">Danh sách</a></li>
        <li><a href="admin/loaitin/them.html">Thêm</a></li>

      </ul>
    </li>
    <li class="submenu"> <a href="#"><i class="icon icon-th-list"></i> <span>Tin</span> <span class="label label-important"></span></a>
      <ul>
        <li><a href="admin/tin/danhsach.html">Danh sách</a></li>
        <li><a href="admin/tin/them.html">Thêm</a></li>

      </ul>
    </li>

    <li class="submenu"> <a href="#"><i class="icon icon-th-list"></i> <span>Bình luận</span> <span class="label label-important"></span></a>
      <ul>
         <li><a href="admin/binhluan/danhsach1.html">Danh sách chưa duyệt</a></li>
        <li><a href="admin/binhluan/danhsach.html">Danh sách đã duyệt</a></li>
        

      </ul>
    </li>

  </ul>
</div>
<!--sidebar-menu--><?php /**PATH C:\xampp\htdocs\tttn\resources\views/admin/layout/menu.blade.php ENDPATH**/ ?>