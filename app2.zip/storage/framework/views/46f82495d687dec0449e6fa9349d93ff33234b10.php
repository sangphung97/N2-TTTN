<?php $__env->startSection('nav'); ?>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark" style="position:sticky;top:0;z-index:1000">
    <!-- Brand -->
    
  
    <!-- Links -->
    
    <ul class="navbar-nav">     
      <li class="nav-item">
       <a href="<?php echo e(Route('index')); ?>" class="navbar-brand"><i class="fas fa-home" style="color:white"></i></a>
      </li>
      <!-- Dropdown -->
      <?php $__currentLoopData = $nhomtin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($nt->trangthai==1): ?>
      <li class="nav-item dropdown">
        
        <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown" style="color:white!important">
          <?php echo e($nt->ten_nhomtin); ?>

        </a>
         <?php $__currentLoopData = $nt->loaitin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="dropdown-menu">
          <a class="dropdown-item" href="<?php echo e(Route('loaitin',['id'=>$tt->id_loaitin,'loaitinseo'=>$tt->loaitinseo])); ?>" ><?php echo e($tt->ten_loaitin); ?></a>
          
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </li>
      <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <form class="form-inline" action="<?php echo e(Route('timkiem')); ?>" method="POST">
      <?php echo csrf_field(); ?>
       <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>";>
        <input class="form-control mr-sm-2" type="text" name="tukhoa" placeholder="Search">
        <button class="btn btn-success" type="submit">Search</button>
    </form>
  </nav>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\tttn\resources\views/frontend/layout/navigation.blade.php ENDPATH**/ ?>