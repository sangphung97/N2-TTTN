<?php $__env->startSection('content'); ?>



<div id="content">


<div id="content-header">
    <div id="breadcrumb"> <a title="" class="tip-bottom"><i class="icon-home"></i> Nhóm tin</a></div>
  </div>
  <div class="container-fluid">

    <hr>
    <div class="row-fluid">
      <div class="span12">
         <?php if(session('thongbao')): ?>
          <div class="alert">
            
            <?php echo e(session('thongbao')); ?>

          </div>
          <?php endif; ?>
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>Danh sách tin</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
              <thead>
                <tr>
                  <th>ID tin</th>
                  <th>Tiêu đề</th>
                  <th>Số lần xem</th>
                  <th>Nhóm tin</th>
                  <th>Loại tin</th>
                  
                  <th>Trạng thái</th>
                  <th>Tác giả</th>
                  <th>Thời gian</th>
                  <th>Thao tác</th>
                  <th>Thao tác</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $tin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
                <tr class="gradeX">
                  <td><?php echo e($t->id_tin); ?></td>
                  <td><?php echo e($t->tieude); ?>

                      <br>
                    <img  width="100px;" src="upload/tintuc/<?php echo e($t->hinhdaidien); ?>"></td>
                  <td><?php echo e($t->solanxem); ?></td>
                 <td>
                      <?php echo e($t->loaitin->nhomtin->ten_nhomtin); ?>

                    </td>
                     <td>
           <?php echo e($t->loaitin->ten_loaitin); ?>

                    </td>
                  <td>
                    <?php if($t->trangthai==1): ?>
                      Hiện
                      <?php else: ?>
                      Ẩn
                   <?php endif; ?>
                     </td>
               <td><?php echo e($t->tacgia); ?></td>
                <td><?php echo e($t->ngaydangtin); ?></td>
            <td class="center"><div class="form-actions" style="padding:0px; margin: 0px; border: 0px; ">
              <form  action="admin/tin/sua-<?php echo e($t->id_tin); ?>.html">
              <button type="submit" class="btn btn-mini">Sửa</button></form>
         </div></td>
            <td class="center"><div class="form-actions" style="padding:0px; margin: 0px; border: 0px; ">
            <form  action="admin/tin/xoa-<?php echo e($t->id_tin); ?>.html">
              <button type="submit" class="btn btn-mini">Xóa</button></form>
            </div></td>
               </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


           
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tttn\resources\views/admin/tin/danhsach.blade.php ENDPATH**/ ?>