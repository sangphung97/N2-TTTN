<?php $__env->startSection('title','Loại Tin'); ?>
<?php echo $__env->make('frontend.layout.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box"style="background-color: #edeff2">
        <div class="container-fluid" style="padding:2% 5%" >
            <div class="row justify-content-between" >
                <div class="col-4">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima, impedit sunt quas eos esse aut adipisci vero praesentium, qui reprehenderit ipsam incidunt obcaecati natus voluptatibus ratione aliquam. Ex, sint cum.
                </div>
                <div class="col-4">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptas, dolorem. Excepturi, minus a! Repellendus sint vero deserunt sapiente. Excepturi repudiandae ab exercitationem suscipit quaerat aut iste repellat quod rerum assumenda!
                </div>
            </div>
        </div>
    </div>
    
    
    <div class="container-fluid"style="margin:35px auto;max-width:1575px">
        <div class="row">
            <div class="col-md-6">
                <h3 style="font-size:4rem">
                    Loại Tin
                </h3>
            </div>
        </div>
        <div class="row" style="outline:1px solid;padding:2% 0;position:relative;margin-top:40px">
            <div class="my-title">
                <h4 style="font-size:2rem">
                    <?php echo e($loai->ten_loaitin); ?>

                </h4>
            </div>
            <?php $__currentLoopData = $tintuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12">
                    
                    <div class="row" style="margin-top:40px;padding-left:25px">
                        
                        <div class="col-md-3">
                            
                            <img src="<?php echo e(asset('upload/tintuc/'.$tt->hinhdaidien)); ?>" alt="category" style="width:100%">
                           
                        </div>
                        
                        <div class="col-md-9 row">
                            
                            <div class="col align-self-start">
                                <a href="<?php echo e(Route('tintuc',['id'=>$tt->id_tin,'tieudeseo'=>$tt->tieudeseo])); ?>">
                                    <h5 style="font-size: 2rem">
                                        <b><?php echo e($tt->tieude); ?></b>
                                    </h5>
                                    <p>
                                        <?php echo e($tt->mota); ?>

                                    </p>
                                    <p>
                                        <?php echo e($tt->noidung); ?>

                                    </p>
                                </a>
                            </div>
                            <div class="col align-self-end" style="flex-basis: auto">
                                    
                                    <span>
                                        Ngày đăng tin | <?php echo e($tt->ngaydangtin); ?>

                                    </span>
                                    <a href="#">
                                        By Tác giả: <?php echo e($tt->tacgia); ?>

                                    </a>
                                    <span>
                                    | Lượt xem: <?php echo e($tt->luotxem); ?>

                                    </span>
                            </div>
                        </div>  
                    </div>
                    
                
            
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tttn\resources\views/frontend/news_category.blade.php ENDPATH**/ ?>