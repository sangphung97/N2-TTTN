<?php $__env->startSection('content'); ?>





<div id="content">


<div id="content-header">
    <div id="breadcrumb"> <a title="" class="tip-bottom"><i class="icon-home"></i> Nhóm tin</a></div>
  </div>



  
  <div class="container-fluid">

    <hr>
    <div class="row-fluid">
      <div class="span12">
         <?php if(session('thongbao')): ?>
          <div class="alert">
            
            <?php echo e(session('thongbao')); ?>

          </div>
          <?php endif; ?>
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>Danh sách nhóm tin</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
              <thead>
                <tr>
                  <th>ID nhóm tin</th>
                  <th>Tên nhóm tin</th>
                  <th>Trạng thái</th>
                  <th  >Thao tác</th>
                  <th  >Thao tác</th>

                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $nhomtin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 
                <tr class="gradeX">

                  <td><?php echo e($nt->id_nhomtin); ?></td>
                  <td><a href="<?php echo e(route('danhsachnhomtin',['id_nhomtin'=>$nt->id_nhomtin])); ?>"><?php echo e($nt->ten_nhomtin); ?></a></td>
                  <td>
              

    
                    <?php if($nt->trangthai==1): ?>
                      Hiện
                      <?php else: ?>
                      Ẩn
                   <?php endif; ?>
                    

                     </td>
               
            <td class="center"><div class="form-actions" style="padding:0px; margin: 0px; border: 0px; ">
              <form  action="admin/nhomtin/sua-<?php echo e($nt->id_nhomtin); ?>.html">
              <button type="submit" class="btn btn-mini">Sửa</button></form>

              
              
            </div></td>
            <td class="center"><div class="form-actions" style="padding:0px; margin: 0px; border: 0px; ">
             

              <form  action="admin/nhomtin/xoa-<?php echo e($nt->id_nhomtin); ?>.html">
              <button type="submit" class="btn btn-mini">Xóa</button></form>
              
            </div></td>

            
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


           
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tttn\resources\views/admin/nhomtin/danhsach.blade.php ENDPATH**/ ?>