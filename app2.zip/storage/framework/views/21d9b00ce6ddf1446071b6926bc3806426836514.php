<?php $__env->startSection('content'); ?>

<!--
<link rel="stylesheet" href="admin_asset/css/bootstrap.min.css" />
<link rel="stylesheet" href="admin_asset/css/bootstrap-responsive.min.css" />
<link rel="stylesheet" href="admin_asset/css/colorpicker.css" />
<link rel="stylesheet" href="admin_asset/css/datepicker.css" />
<link rel="stylesheet" href="admin_asset/css/uniform.css" />
<link rel="stylesheet" href="admin_asset/css/select2.css" />
<link rel="stylesheet" href="admin_asset/css/matrix-style.css" />
<link rel="stylesheet" href="admin_asset/css/matrix-media.css" />
<link rel="stylesheet" href="admin_asset/css/bootstrap-wysihtml5.css" />
<link href="admin_asset/font-awesome/css/font-awesome.css" rel="stylesheet" />-->


<div id="content">

<div id="content-header">
    <div id="breadcrumb"> <a title="" class="tip-bottom"><i class="icon-home"></i> Nhóm tin</a></div>
  </div>
<div class="container-fluid" >
  <hr>
  <div class="row-fluid">
    <div class="span14">

       <?php if(count($errors)>0): ?>
            <div class="alert"> 
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($err); ?><br>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          <?php endif; ?>



          <?php if(session('thongbao')): ?>
          <div class="alert">
            
            <?php echo e(session('thongbao')); ?>

          </div>
          <?php endif; ?>


      <div class="widget-box" >
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i></span>
          <h5>Thêm tin</h5>
        </div>
        <div class="widget-content nopadding">




          <form action="admin/tin/them.html" method="POST" class="form-horizontal" enctype="multipart/form-data">

              <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>

            
            <div class="control-group">
              <label class="control-label">Tiêu đề:</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="" name="tieude" />
              </div>

            

              <label class="control-label">Hình đại diện</label>
              <div class="controls">
                <input type="file" id="file"  name="file" onchange="return fileValidation()" />
              </div>
              <div  id="imagePreview"></div>
         
            <label class="control-label">Nhóm tin:</label>
                <div class="controls">
                <select name="nhomtin" id="nhomtin" class="span8">
                  
                  <?php $__currentLoopData = $nhomtin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option  value="<?php echo e($lt->id_nhomtin); ?>"   ><?php echo e($lt->ten_nhomtin); ?></option>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                  
                 
                </select>
              </div>
                 <label class="control-label">Loại tin</label>

              <div class="controls">
                <select name="loaitin" id="loaitin"  class="span8">
 
                  <?php $__currentLoopData = $loaitin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($lt->id_loaitin); ?>"   ><?php echo e($lt->ten_loaitin); ?></option>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                  
                 
                </select>




              </div>
             <label class="control-label">Tác giả</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="" name="tacgia" />
              </div>
              <label class="control-label">Mô tả:</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="" name="mota" />
              </div>

              <label class="control-label" >Tin</label>
              <div class="controls" >
                <label>
                  <input type="radio"  value="1" name="tinhot" />
                  Hot</label>
                <label>
                  <input type="radio" checked="checked" value="0" name="tinhot" />
                 Bình thường</label>
                
              </div>
            </div>
           
              <label class="control-label">Nội dung:</label>
            <div class="controls">

              <textarea name="noidung" class="textarea_editor span10" rows="12" placeholder="Enter text ...">Nội dung</textarea>
            </div>


            
              
            </div>
         <br>
  
 
                   
            <div class="form-actions">
              <button type="submit" class="btn btn-success">Xác nhận</button>
              
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
  </div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<!--<script src="admin_asset/js/jquery.min.js"></script> 
<script src="admin_asset/js/jquery.ui.custom.js"></script> 
<script src="admin_asset/js/bootstrap.min.js"></script> 
<script src="admin_asset/js/bootstrap-colorpicker.js"></script> 
<script src="admin_asset/js/bootstrap-datepicker.js"></script> 
<script src="admin_asset/js/jquery.toggle.buttons.js"></script> 
<script src="admin_asset/js/masked.js"></script> 
<script src="admin_asset/js/jquery.uniform.js"></script> 
<script src="admin_asset/js/select2.min.js"></script> 
<script src="admin_asset/js/matrix.js"></script> 
<script src="admin_asset/js/matrix.form_common.js"></script> -->
<script src="admin_asset/js/wysihtml5-0.3.0.js"></script> 
<script src="admin_asset/js/jquery.peity.min.js"></script> 
<script src="admin_asset/js/bootstrap-wysihtml5.js"></script> 

<script>
  $('.textarea_editor').wysihtml5();
</script>
  <script>
function fileValidation(){
var fileInput = document.getElementById('file');
var filePath = fileInput.value;//lấy giá trị input theo id
var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif)$/i;//các tập tin cho phép
//Kiểm tra định dạng
if(!allowedExtensions.exec(filePath)){
alert('Vui lòng upload các file có định dạng: .jpeg/.jpg/.png/.gif only.');
fileInput.value = '';
return false;
}else{
//Image preview
if (fileInput.files && fileInput.files[0]) {
var reader = new FileReader();
reader.onload = function(e) {
document.getElementById('imagePreview').innerHTML = '<img style="width:700px;height:400px;" src="'+e.target.result+'"/>';
};
reader.readAsDataURL(fileInput.files[0]);
}
}
}
</script>
<script >
  $(document).ready(function(){
     $("#nhomtin").select2("destroy");
        $("#loaitin").select2("destroy");
   $("#nhomtin").change(function(){
    var idnhomtin=$(this).val();
    $.get("admin/ajax/loaitin/"+idnhomtin,function(data){

            $("#loaitin").select2("destroy");
            $("#loaitin").html(data);
    });
   });
  });



</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tttn\resources\views/admin/tin/them.blade.php ENDPATH**/ ?>